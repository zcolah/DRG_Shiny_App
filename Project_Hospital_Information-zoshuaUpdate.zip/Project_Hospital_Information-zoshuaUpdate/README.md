# Hospital-Information
I have made a map that shows the hospitals that fit the chosen DRG and amount of money that people are willing to pay.